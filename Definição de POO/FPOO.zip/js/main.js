function MudaDesenho(){

    const texto = document.querySelector("h1");
    const texto2 = document.querySelector(".texto1");
    const texto3 = document.querySelector(".texto2");
    const texto4 = document.querySelector(".objetosreais");
    const texto5 = document.querySelector(".objetosabstratos");
    const imagem = document.querySelector("img");
    const imagem2=document.querySelector("#img2");
    const imagem3=document.querySelector("#img3");
    const imagem4=document.querySelector("#img4");
    const imagem5=document.querySelector("#img5");
    const imagem6=document.querySelector("#img6");
    const valor = document.querySelector('#valor').value;
    const test ="";
    
    
    if(valor=="classe" || valor== "Classe"){
        texto.innerHTML = "Classe";
        imagem.setAttribute("src","img/classe2.png");
        imagem.setAttribute("width","300px");
        texto2.innerHTML="Uma classe é um gabarito para a definição de objetos. Através da definição de uma classe, descreve-se que propriedades -- ou atributos -- o objeto terá.Além da especificação de atributos, a definição de uma classe descreve também qual o comportamento de objetos da classe, ou seja, que funcionalidades podem ser aplicadas a objetos da classe.";
        imagem2.setAttribute("src","img/classe.gif");
        imagem2.setAttribute("height","250px");

        texto3.innerHTML="Classes Abstratas:É um tipo de classe especial que não pode ser instanciada, apenas herdada. Sendo assim, uma classe abstrata não pode ter um objeto criado a partir de sua instanciação. Essas classes são muito importantes quando não queremos criar um objeto a partir de uma classe “geral”, apenas de suas “subclasses”.";
        imagem3.setAttribute("src","img/classeabstratapng.png");
        imagem3.setAttribute("height","300px");

        texto4.innerHTML="Classes Internas:As classes internas em Java são mais que classes definidas dentro de outras classes. A definição destas classes implica que existe uma relação estreita entre uma classe interna e a externa que a contém. A definição é tal que as instâncias de classes internas têm acesso implícito às instâncias das classes externas, no contexto das quais foram criadas.Declaramos classes exatamente como fazíamos antes, mas agora ela está dentro do corpo de outra classe.Consequentemente dentro do arquivo .java desta outra classe).As suas regras de acesso são um pouquinho diferentes.O uso mais comum das classes internas é para lidar com eventos, como veremos mais a frente.Classes Internas";
        imagem4.setAttribute("src","img/classeinterna.png");
        imagem4.setAttribute("height","300px");

        texto5.innerHTML="Classes Anônimas:Classes anônimas te permitem criar um código mais conciso. Elas te permitem declarar e instanciar uma classe ao mesmo tempo. Elas são como classes locais exceto pelo fato de que elas não possuem nome.Enquanto classes locais são classes declaradas, as classes anônimas são expressões o que significa que você define a classe em outra expressão.";
        imagem5.setAttribute("src","img/classeanonima.png");
        imagem5.setAttribute("height","300px");

        document.body.style.backgroundColor = '#6A5ACD';
        document.body.style.color = 'black';
    
    }
    else if(valor=="objeto" || valor=="Objeto"){
        texto.innerHTML = "Objeto";
        imagem.setAttribute("src","img/objeto.gif");
        imagem.setAttribute("width","300px");   
        imagem2.setAttribute("height","300px");
        test = imagem2.setAttribute("src","img/instanciaeobjeto.png");
        texto2.innerHTML="O objeto é, na verdade, uma aglutinação de estados e comportamentos.Conceitualmente falando, um objeto é um elemento que representa alguma entidade, quer seja abstrata quer seja concreta, da área de interesse do problema que está sendo analisado. Portanto, esse paradigma aproxima o mundo real do mundo virtual.";
       

        texto4.innerHTML="Objetos reais: uma pessoa, um livro, um carro, um avião, um eletrodoméstico, um notebook etc.";
        imagem4.setAttribute("src","img/objetosinstancia2png.png");
        imagem4.setAttribute("width","300px");

        texto5.innerHTML="Objetos abstratos: as funções de pessoas nos sistemas – cliente, vendedor, representante, gerente, usuário etc.";
        document.body.style.backgroundColor = '	#363636';
        document.body.style.color = 'white';
        
        imagem3.setAttribute("src","img/codigoobjeto.png");
        imagem3.setAttribute("width","300px");

       

    }
    
    else{
        texto.innerHTML = "Classe ou Objeto não encontrado😮 =(";
        imagem.setAttribute("src","img/x.webp");
        imagem.setAttribute("width","300px");
        document.body.style.backgroundColor = 'red';
        document.body.style.color = 'white';
    }
}
var modal = document.getElementById("myModal");


var btn = document.getElementById("myBtn");


var span = document.getElementsByClassName("close")[0];


btn.onclick = function() {
  modal.style.display = "block";
}


span.onclick = function() {
  modal.style.display = "none";
}

window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
